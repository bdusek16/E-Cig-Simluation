/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stage2;
import java.awt.event.*; 
import java.awt.*; 
import javax.swing.*; 
/**
 *
 * @author class50040
 */
public class ECigSimExtraYes {
    
    
    private static void yesActionPerformed(java.awt.event.ActionEvent evt) {                                          
        // TODO add your handling code here:
    }                                         

    private static void noActionPerformed(java.awt.event.ActionEvent evt) {                                         
        // TODO add your handling code here:
    } 
    
    /**
     * @param args the command line arguments
     */   
    public static void main(String[] args) {
        JFrame f = new JFrame("frame");
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JPanel pan = new JPanel();
        JDialog d = new JDialog(f, "Dialog Box Yes");
        pan.setLayout(new FlowLayout());
        d.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        d.setSize(860, 460);
        
        ImageIcon img = new ImageIcon(ECigSimExtraYes.class.getResource("/images/vaping.png"));
        JLabel l = new JLabel("You feel different. You almost want to keep doing it but you convince yourself you have more work to do.");
        JLabel k = new JLabel("As you go home, your mind wanders back to the E-cig and how it made you feel.");
        JLabel bkgd = new JLabel();
        
        bkgd.setIcon(img); // NOI18N
        l.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        k.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N   
        JButton yes = new JButton("Press to Continue");
        
        pan.add(l);
        pan.add(k);
        d.getContentPane().add(yes);
        d.getContentPane().add(bkgd);
        bkgd.setBounds(0, 0, 1000, 600);
        yes.setBounds(340, 340, 180, 70);
        d.add(pan);
        
        d.setLocationRelativeTo(null);
        d.setVisible(true);
        
        
        d.addWindowListener(new WindowAdapter(){
            public void windowClosed(WindowEvent e)
            {
                f.dispose();
            }
            
            public void windowClosing(WindowEvent e)
            {
                f.dispose();
            }
        });
        
        yes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Scene1 scene2 = new Scene1();
                scene2.setVisible(true);
                f.dispose();
            }
        });
    }
}
